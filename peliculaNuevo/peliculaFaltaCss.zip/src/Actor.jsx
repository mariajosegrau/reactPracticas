const Actor = (actor) => {

    return (
        <>
            <img src={actor.imagen} />
            <h3>{actor.nombre}</h3>
            <p>{actor.biografia}</p>
        </>
    );

}
export default Actor;