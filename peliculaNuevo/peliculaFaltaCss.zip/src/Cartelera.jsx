
const Cartelera = ({link_cartelera}) => {

    return(
        <img src= {link_cartelera} alt="cartel" />
    );
}
export default Cartelera;