const Elenco = ({ actores }) => {
    //javascript

    return (
        //jsx
        <>
            <h3>Elenco</h3>

            {actores.map((actor) => (
                <div>
                    <img src={actor.imagen} alt="img_actor" />
                    <h4>{actor.nombre}</h4>
                    <p>{actor.biografia}</p>
                </div>
            )
            )}
        </>
    );

};

export default Elenco;