import Cartelera from "./Cartelera.jsx";
import Resumen from './Resumen.jsx';
import Elenco from './Elenco.jsx';

const Pelicula = ({ children, nombre, director, link_cartelera, actores }) => {

    return (
        //jsx
        <>
            <h1>{nombre}</h1>
            <h3>{director}</h3>
            <Cartelera link_cartelera={link_cartelera}></Cartelera>
            <Resumen>{children}</Resumen>
            <Elenco actores={actores}></Elenco>
        
        </>
    );

}
export default Pelicula;