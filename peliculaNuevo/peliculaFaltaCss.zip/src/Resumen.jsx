const Resumen = ({children}) => {
    return(
        <p>
            {children}
        </p>
        
    );
}
export default Resumen;